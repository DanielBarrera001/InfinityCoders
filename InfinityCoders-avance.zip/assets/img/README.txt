Acá van las imágenes reales (fotos de planetas, texturas, etc.) si el
equipo decide reemplazar las esferas dibujadas por CSS en destinos.html
por imágenes reales más adelante.

Nota: Git no sube carpetas vacías, por eso este archivo existe: en
cuanto agreguen una imagen real, pueden borrar este README.
