Acá van íconos propios (favicon, íconos SVG para los botones, etc.).

Nota: Git no sube carpetas vacías, por eso este archivo existe: en
cuanto agreguen un ícono real, pueden borrar este README.
