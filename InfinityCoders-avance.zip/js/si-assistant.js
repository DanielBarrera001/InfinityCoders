/* ============================================================
   INFINITYCODERS · si-assistant.js
   Módulo del "Asistente de Misión" (Especialista en IA)
   ------------------------------------------------------------
   Este archivo es un PUNTO DE PARTIDA, no la versión final.
   Ahora mismo responde con texto fijo (respuestas "enlatadas")
   buscando palabras clave en la pregunta. La idea es que, más
   adelante, quien lleve la parte de IA reemplace el contenido
   de responderAsistente() por una llamada real a un modelo.

   IMPORTANTE sobre seguridad (para cuando conecten una IA real):
   nunca pongan una API key directamente en un archivo .js que
   se sube al navegador (cualquiera podría verla con F12 →
   Sources). Lo correcto es crear una pequeña función/servidor
   intermedio (por ejemplo con Vercel, Netlify Functions o un
   backend propio) que reciba la pregunta, llame a la IA con la
   key guardada del lado del servidor, y devuelva la respuesta.
   ============================================================ */

/* Base de respuestas por palabra clave. Si ninguna coincide,
   usamos la respuesta "default" al final de la función. */
function responderAsistente(pregunta) {
  const texto = pregunta.toLowerCase();

  // Si preguntan por un planeta específico, respondemos con sus
  // datos reales tomados de window.InfinityCoders.planetas (el
  // mismo objeto que usa destinos.html, definido en main.js).
  const planetas = (window.InfinityCoders && window.InfinityCoders.planetas) || [];
  const planetaMencionado = planetas.find((p) => texto.includes(p.nombre.toLowerCase()));

  if (planetaMencionado) {
    return `${planetaMencionado.nombre} es un ${planetaMencionado.clasificacion.toLowerCase()}. Gravedad: ${planetaMencionado.gravedad} m/s², temperatura promedio: ${planetaMencionado.temperatura}. Puedes ver su ficha completa en la página de Destinos.`;
  }

  if (texto.includes("infinitycoders") || texto.includes("equipo") || texto.includes("quiénes")) {
    return "InfinityCoders es el equipo formado por Gaby, Adriel, Mónica y Cristopher para la competencia Código TBox. Este sitio es nuestro recorrido interactivo por el sistema solar.";
  }

  if (texto.includes("peso") || texto.includes("gravedad")) {
    return "Puedes calcular tu peso en cualquier planeta en la página de Destinos: elige un planeta y escribe tu peso en la Tierra en el simulador.";
  }

  if (texto.includes("hola") || texto.includes("ayuda")) {
    return "¡Hola, explorador/a! Puedo darte datos sobre cualquier planeta del sistema solar. Prueba preguntando, por ejemplo, 'háblame de Marte'.";
  }

  // Respuesta por defecto si no reconocimos ninguna palabra clave
  return "Todavía estoy aprendiendo sobre eso. Por ahora puedo hablarte de cualquier planeta del sistema solar o del equipo InfinityCoders — ¡pregúntame!";
}

/* ---------- Ejemplo de cómo se vería la versión con una IA real ----------
   (código de referencia, NO se ejecuta: lo dejamos como comentario
   para cuando el Especialista en IA quiera reemplazar la función
   de arriba por esto, apuntando a su propio backend)

async function responderAsistenteConIA(pregunta) {
  const respuesta = await fetch("/api/asistente", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ pregunta }),
  });
  const datos = await respuesta.json();
  return datos.texto;
}
*/
