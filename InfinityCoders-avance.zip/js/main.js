/* ============================================================
   INFINITYCODERS · main.js
   JS COMPARTIDO (responsabilidad de los 4 integrantes)
   ------------------------------------------------------------
   Este archivo se carga en TODAS las páginas (index.html y
   destinos.html), por eso cada bloque revisa primero si los
   elementos que necesita existen en el HTML (con "if (elemento)")
   antes de usarlos. Así evitamos errores en consola cuando una
   función busca algo que solo existe en la otra página.

   Estructura de este archivo:
     1. Datos de los planetas   (compartidos con si-assistant.js)
     2. Fondo de estrellas       (todas las páginas)
     3. Menú móvil               (todas las páginas)
     4. Reloj de misión (MET)    (todas las páginas)
     5. Animación al hacer scroll (todas las páginas)
     6. Selector de planetas      (solo destinos.html)
     7. Simulador de peso         (solo destinos.html)
     8. Asistente de misión (chips) (solo index.html)
   ============================================================ */

/* ---------- 1. DATOS DE LOS PLANETAS ----------
   Objeto con la info de los 8 planetas. Lo guardamos dentro de
   "window.InfinityCoders" para que si-assistant.js (otro archivo)
   también pueda usar estos mismos datos sin tener que copiarlos.
   Los valores de gravedad/temperatura/distancia son aproximados,
   tomados de referencias astronómicas generales (uso educativo). */
window.InfinityCoders = window.InfinityCoders || {};

window.InfinityCoders.planetas = [
  {
    id: "mercurio",
    nombre: "Mercurio",
    clasificacion: "Planeta Rocoso",
    colorA: "#9c9c9c",
    colorB: "#3d3d3d",
    bandas: false,
    anillo: false,
    gravedad: 3.7,
    temperatura: "167 °C",
    distancia: "155 M km",
    dia: "58.6 días terrestres",
    descripcion:
      "El planeta más pequeño y veloz del sistema solar. Al no tener atmósfera que lo proteja, sufre los cambios de temperatura más extremos entre el día y la noche.",
  },
  {
    id: "venus",
    nombre: "Venus",
    clasificacion: "Planeta Rocoso",
    colorA: "#e8c98a",
    colorB: "#6b4a1f",
    bandas: false,
    anillo: false,
    gravedad: 8.87,
    temperatura: "464 °C",
    distancia: "170 M km",
    dia: "243 días terrestres",
    descripcion:
      "El planeta más caliente del sistema solar por su densa atmósfera de CO2, que atrapa el calor como un invernadero. Gira al revés que la mayoría de los planetas.",
  },
  {
    id: "tierra",
    nombre: "Tierra",
    clasificacion: "Planeta Rocoso",
    colorA: "#4f9eea",
    colorB: "#0f2a55",
    bandas: false,
    anillo: false,
    gravedad: 9.81,
    temperatura: "15 °C",
    distancia: "Nuestro hogar",
    dia: "23h 56m",
    descripcion:
      "Nuestro punto de partida. El único planeta conocido con vida, agua líquida en abundancia y una atmósfera respirable. El punto de comparación para todos los demás destinos.",
  },
  {
    id: "marte",
    nombre: "Marte",
    clasificacion: "Planeta Rocoso",
    colorA: "#d98d5f",
    colorB: "#5c2a12",
    bandas: false,
    anillo: false,
    gravedad: 3.71,
    temperatura: "-63 °C",
    distancia: "225 M km",
    dia: "24h 37m",
    descripcion:
      "El planeta rojo. Posee el volcán más grande del sistema solar (Monte Olimpo) y valles secos de ríos antiguos que sugieren que alguna vez tuvo agua líquida.",
  },
  {
    id: "jupiter",
    nombre: "Júpiter",
    clasificacion: "Gigante Gaseoso",
    colorA: "#e0b788",
    colorB: "#6e4a2a",
    bandas: true,
    anillo: false,
    gravedad: 24.79,
    temperatura: "-110 °C",
    distancia: "629 M km",
    dia: "9h 56m",
    descripcion:
      "El gigante más grande del sistema solar. Su Gran Mancha Roja es una tormenta más ancha que la Tierra que lleva activa siglos de siglos.",
  },
  {
    id: "saturno",
    nombre: "Saturno",
    clasificacion: "Gigante Gaseoso",
    colorA: "#d8c28a",
    colorB: "#5e4d26",
    bandas: true,
    anillo: true,
    gravedad: 10.44,
    temperatura: "-140 °C",
    distancia: "1,276 M km",
    dia: "10h 42m",
    descripcion:
      "Famoso por sus espectaculares anillos de hielo y roca. Es el planeta menos denso del sistema solar: en teoría, flotaría en una piscina lo bastante grande.",
  },
  {
    id: "urano",
    nombre: "Urano",
    clasificacion: "Gigante de Hielo",
    colorA: "#a7e8e0",
    colorB: "#2d5d58",
    bandas: true,
    anillo: false,
    gravedad: 8.69,
    temperatura: "-195 °C",
    distancia: "2,596 M km",
    dia: "17h 14m",
    descripcion:
      "Un gigante de hielo que gira prácticamente de lado, con un eje de rotación inclinado casi 98°, probablemente por un impacto antiguo.",
  },
  {
    id: "neptuno",
    nombre: "Neptuno",
    clasificacion: "Gigante de Hielo",
    colorA: "#5b7fe0",
    colorB: "#152452",
    bandas: true,
    anillo: false,
    gravedad: 11.15,
    temperatura: "-200 °C",
    distancia: "4,053 M km",
    dia: "16h 6m",
    descripcion:
      "El planeta más ventoso del sistema solar, con ráfagas que superan los 2,000 km/h. Es el mundo más alejado del Sol.",
  },
];

/* Todo el código de abajo espera a que el HTML esté completamente
   cargado antes de buscar elementos, para no intentar tocar algo
   que el navegador todavía no dibujó. */
document.addEventListener("DOMContentLoaded", () => {
  inicializarEstrellas();
  inicializarMenuMovil();
  inicializarRelojMision();
  inicializarScrollReveal();
  inicializarSelectorPlanetas();
  inicializarSimuladorPeso();
  inicializarChipsAsistente();
});

/* ---------- 2. FONDO DE ESTRELLAS ----------
   Busca el contenedor ".stars-layer" (debe existir en el <body>
   de index.html y destinos.html) y le agrega N estrellitas en
   posiciones aleatorias, cada una con su propio tamaño y demora
   de parpadeo (para que no todas titilen al mismo tiempo). */
function inicializarEstrellas(cantidad = 120) {
  const capa = document.querySelector(".stars-layer");
  if (!capa) return; // esta página no tiene fondo de estrellas, salimos

  const fragmento = document.createDocumentFragment();

  for (let i = 0; i < cantidad; i++) {
    const estrella = document.createElement("span");
    estrella.className = "star";

    const tamano = Math.random() * 2 + 1; // entre 1px y 3px
    estrella.style.width = `${tamano}px`;
    estrella.style.height = `${tamano}px`;
    estrella.style.top = `${Math.random() * 100}%`;
    estrella.style.left = `${Math.random() * 100}%`;
    estrella.style.animationDelay = `${Math.random() * 3}s`;

    fragmento.appendChild(estrella);
  }

  capa.appendChild(fragmento);
}

/* ---------- 3. MENÚ MÓVIL ----------
   El botón hamburguesa (.nav-toggle) agrega/quita la clase
   "abierto" en la lista de enlaces (.nav-links). El CSS se
   encarga de mostrarlo u ocultarlo (ver styles.css, sección 19). */
function inicializarMenuMovil() {
  const boton = document.querySelector(".nav-toggle");
  const enlaces = document.querySelector(".nav-links");
  if (!boton || !enlaces) return;

  boton.addEventListener("click", () => {
    enlaces.classList.toggle("abierto");
  });

  // Si tocan un enlace del menú móvil, lo cerramos automáticamente
  enlaces.querySelectorAll("a").forEach((enlace) => {
    enlace.addEventListener("click", () => enlaces.classList.remove("abierto"));
  });
}

/* ---------- 4. RELOJ DE MISIÓN (MET) ----------
   "MET" = Mission Elapsed Time. Contamos los segundos desde que
   se abrió la página y los mostramos como T+ HH:MM:SS, como en
   un panel real de control de misión. */
function inicializarRelojMision() {
  const reloj = document.querySelector("#met-clock");
  if (!reloj) return;

  const inicio = Date.now();

  function actualizar() {
    const segundosTotales = Math.floor((Date.now() - inicio) / 1000);
    const horas = String(Math.floor(segundosTotales / 3600)).padStart(2, "0");
    const minutos = String(Math.floor((segundosTotales % 3600) / 60)).padStart(2, "0");
    const segundos = String(segundosTotales % 60).padStart(2, "0");
    reloj.textContent = `T+ ${horas}:${minutos}:${segundos}`;
  }

  actualizar();
  setInterval(actualizar, 1000);
}

/* ---------- 5. REVELAR ELEMENTOS AL HACER SCROLL ----------
   Cualquier elemento con la clase "reveal" empieza invisible
   (ver CSS). Con IntersectionObserver detectamos cuándo entra
   en pantalla y le agregamos "visible" para que aparezca con
   una animación suave. */
function inicializarScrollReveal() {
  const elementos = document.querySelectorAll(".reveal");
  if (!elementos.length) return;

  const observador = new IntersectionObserver(
    (entradas) => {
      entradas.forEach((entrada) => {
        if (entrada.isIntersecting) {
          entrada.target.classList.add("visible");
          observador.unobserve(entrada.target); // ya no hace falta seguir observando
        }
      });
    },
    { threshold: 0.15 }
  );

  elementos.forEach((el) => observador.observe(el));
}

/* ---------- 6. SELECTOR DE PLANETAS (destinos.html) ----------
   Cuando el usuario hace clic en un botón de planeta, buscamos
   sus datos en window.InfinityCoders.planetas y actualizamos la
   tarjeta de detalle: nombre, descripción, estadísticas y los
   colores de la esfera (mediante variables CSS). */
function inicializarSelectorPlanetas() {
  const botones = document.querySelectorAll(".btn-planeta");
  const contenedorDetalle = document.querySelector("[data-detalle-planeta]");
  if (!botones.length || !contenedorDetalle) return; // no estamos en destinos.html

  botones.forEach((boton) => {
    boton.addEventListener("click", () => pintarPlaneta(boton.dataset.planeta));
  });

  // Al cargar la página mostramos el primer planeta (o el que ya tenga .activo)
  const inicial = document.querySelector(".btn-planeta.activo") || botones[0];
  if (inicial) pintarPlaneta(inicial.dataset.planeta);
}

function pintarPlaneta(idPlaneta) {
  const planeta = window.InfinityCoders.planetas.find((p) => p.id === idPlaneta);
  if (!planeta) return;

  // 1) Marcar el botón activo
  document.querySelectorAll(".btn-planeta").forEach((b) => {
    b.classList.toggle("activo", b.dataset.planeta === idPlaneta);
  });

  // 2) Textos de la tarjeta de detalle
  document.querySelector("[data-clasificacion]").textContent = planeta.clasificacion;
  document.querySelector("[data-nombre]").textContent = planeta.nombre;
  document.querySelector("[data-descripcion]").textContent = planeta.descripcion;
  document.querySelector("[data-gravedad]").textContent = `${planeta.gravedad} m/s²`;
  document.querySelector("[data-temperatura]").textContent = planeta.temperatura;
  document.querySelector("[data-distancia]").textContent = planeta.distancia;
  document.querySelector("[data-dia]").textContent = planeta.dia;

  // 3) Colores de la esfera: se los pasamos como variables CSS
  //    al contenedor, y el CSS (sección 14 de styles.css) las lee.
  const visual = document.querySelector("[data-visual-planeta]");
  visual.style.setProperty("--planeta-color", planeta.colorA);
  visual.style.setProperty("--planeta-color-oscuro", planeta.colorB);

  const esfera = document.querySelector("[data-esfera]");
  esfera.classList.toggle("con-bandas", planeta.bandas);

  const anillo = document.querySelector("[data-anillo-saturno]");
  if (anillo) anillo.style.display = planeta.anillo ? "block" : "none";

  // 4) Recalcular el simulador de peso con el nuevo planeta
  actualizarPesoSimulado(planeta);
}

/* ---------- 7. SIMULADOR DE PESO (destinos.html) ----------
   Fórmula: tu peso en otro planeta = tu peso en la Tierra
   multiplicado por (gravedad del planeta / gravedad de la Tierra).
   La gravedad de la Tierra que usamos como referencia es 9.81 m/s². */
const GRAVEDAD_TIERRA = 9.81;

function inicializarSimuladorPeso() {
  const input = document.querySelector("#peso-tierra");
  if (!input) return; // no estamos en destinos.html

  input.addEventListener("input", () => {
    const planetaActivo = document.querySelector(".btn-planeta.activo");
    const planeta = window.InfinityCoders.planetas.find(
      (p) => p.id === (planetaActivo ? planetaActivo.dataset.planeta : "marte")
    );
    if (planeta) actualizarPesoSimulado(planeta);
  });
}

function actualizarPesoSimulado(planeta) {
  const input = document.querySelector("#peso-tierra");
  const salida = document.querySelector("[data-peso-resultado]");
  if (!input || !salida) return;

  const pesoTierra = parseFloat(input.value) || 0;
  const pesoLocal = pesoTierra * (planeta.gravedad / GRAVEDAD_TIERRA);

  salida.textContent = `Tu peso en ${planeta.nombre}: ${pesoLocal.toFixed(1)} kg`;
}

/* ---------- 8. CHIPS DEL ASISTENTE (index.html) ----------
   La lógica "inteligente" de las respuestas vive en
   js/si-assistant.js (es responsabilidad del Especialista en IA).
   Aquí solo conectamos el clic de cada chip con esa función,
   si es que existe en la página. */
function inicializarChipsAsistente() {
  const chips = document.querySelectorAll(".chip[data-pregunta]");
  const salida = document.querySelector(".asistente-salida");
  if (!chips.length || !salida) return;

  chips.forEach((chip) => {
    chip.addEventListener("click", () => {
      const pregunta = chip.dataset.pregunta;
      // responderAsistente() está definida en si-assistant.js
      if (typeof responderAsistente === "function") {
        salida.innerHTML = `<strong>Tú:</strong> ${pregunta}<br><br><strong>Asistente:</strong> ${responderAsistente(pregunta)}`;
      }
    });
  });
}
